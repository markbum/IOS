(function($p){
	$p.Setting={
		//0 H5本次存储，1 Sqlite存储
		StoreType:0,
		appSettingKey: "platform.setting",
		//用户Key，获取用户基本信息
		userKey: "platform.user",
		//用户状态
		userStatusKey: "platform.userstatus",
		//用户登陆信息
		userLoginInfo: "platform.userLoginInfo",
		//最后一次更新时间
		lastUpdateData: "platform.lastUpdateData",
		//服务地址字符串
		serverUrl: "platform.serverurl",
		//项目名称
		projectname:"default",
		//调试连接字符串
		debugServerUrl:"",
		LogonSuccess:function(userInfo){
			return true;
		}
	};
})(window.platform=window.platform||{});
