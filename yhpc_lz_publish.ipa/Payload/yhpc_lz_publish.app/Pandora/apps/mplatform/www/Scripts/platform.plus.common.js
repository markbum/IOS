if(!window.platformCommon) {
	window.platformCommon = {};
}
(function(owner) {
	if(window.plus) {
		InitPlugin();
	} else {
		document.addEventListener("plusready", function() {
			InitPlugin();
		});
	}
	var defaultPointsCount = 8;

 function outSet(msg)
 {
 mui.toast(msg);
 }
	function InitPlugin() {
	// 监听点击消息事件
	plus.push.addEventListener( "click", function( msg ) {
                               // 判断是从本地创建还是离线推送的消息
                               switch( msg.payload ) {
                               case "LocalMSG":
                               outSet( "点击本地创建消息启动：" );
                               break;
                               default:
                               outSet( "点击离线推送消息启动：");
                               break;
                               }
                               // 提示点击的内容
                               plus.nativeUI.alert( msg.content );
                               // 处理其它数据
                               }, false );
	// 监听在线消息事件
	plus.push.addEventListener( "receive", function( msg ) {
                               if ( msg.aps ) {  // Apple APNS message
                               outSet( "接收到在线APNS消息：" );
                               } else {
                               outSet( "接收到在线透传消息：" );
                               }
                               }, false );
 
 
 
		var tools = window.plus.tools;
		var _BARCODE = 'platform',
			B = window.plus.bridge;

		var pluginMethodAction = {
			/*
			 *@description 异步加载
			 * */
			PluginFunction: function(methodName, ArgusObj, successCallback, errorCallback) {
				var success = typeof successCallback !== 'function' ? null : function(args) {
						successCallback(args);
					},
					fail = typeof errorCallback !== 'function' ? null : function(code) {
						errorCallback(code);
					};
				callbackID = B.callbackId(success, fail);
				return B.exec(_BARCODE, methodName, [callbackID, ArgusObj]);
			},
			/** 
			 * 同步加载
			 * @param {Object} methodName 调用的方法名
			 * @param {Object} ArgusObj  传入的json参数
			 */
			PluginFunctionSync: function(methodName, ArgusObj) {
				return B.execSync(_BARCODE, methodName, [ArgusObj]);
			}
		};

		window.plus.platform = pluginMethodAction;
	}

	/**
	 * 两数相加 a+b
	 * @param {Object} a
	 * @param {Object} b
	 * @param {Object} savePointsCount 保留的小数点
	 */
	owner.add = function(a, b, savePointsCount) {
		if(typeof(savePointsCount) == "undefined") {
			savePointsCount = defaultPointsCount;
		}
		return window.plus.platform.PluginFunctionSync("Add", [a, b, savePointsCount]);
	};
	/**
	 * 两数相减  a-b
	 * @param {Object} a
	 * @param {Object} b
	 * @param {Object} savePointsCount 保留的小数点
	 */
	owner.subtract = function(a, b, savePointsCount) {
		if(typeof(savePointsCount) == "undefined") {
			savePointsCount = defaultPointsCount;
		}
		return window.plus.platform.PluginFunctionSync("Subtract", [a, b, savePointsCount]);
	};
	/**
	 *  两数相乘  a*b
	 * @param {Object} a
	 * @param {Object} b
	 * @param {Object} savePointsCount 保留的小数点
	 */
	owner.multiply = function(a, b, savePointsCount) {
		if(typeof(savePointsCount) == "undefined") {
			savePointsCount = defaultPointsCount;
		}
		return window.plus.platform.PluginFunctionSync("Multiply", [a, b, savePointsCount]);
	};
	/**
	 * 除法  a/b
	 * @param {Object} a
	 * @param {Object} b
	 * @param {Object} savePointsCount 保留的小数点
	 */
	owner.divide = function(a, b, savePointsCount) {
		if(typeof(savePointsCount) == "undefined") {
			savePointsCount = defaultPointsCount;
		}
		return window.plus.platform.PluginFunctionSync("Divide", [a, b, savePointsCount]);
	};
	/**
	 * 累加 
	 * @param {Object} a [1,2,45,656]
	 * @param {Object} savePointsCount 保留的小数点
	 */
	owner.sum = function(a, savePointsCount) {
		if(typeof(savePointsCount) == "undefined") {
			savePointsCount = defaultPointsCount;
		}
		return window.plus.platform.PluginFunctionSync("Sum", [a, savePointsCount]);
	};
	/**
	 * 获取手机的mac地址
	 */
	owner.GetMacAddress = function() {

		var result = window.plus.platform.PluginFunctionSync("GetMacAddress", null);
		return result.Mac;
	};

	owner.GetWIFIMacAddress = function() {

		var result = window.plus.platform.PluginFunctionSync("GetWIFIMacAddress", null);
		return result.Mac;
	};

	/**
	 * 获取当前的压强
	 * @param {Object} callback
	 */
	owner.GetPressure = function(callback) {

		window.plus.platform.PluginFunction("GetPressure", null, function(result) {
			if(result == -9999)
				result = null;
			callback(result);
		});
	};

	/**
	 * 获取服务的地址
	 */
	owner.GetServerUrl = function() {
		//从缓存中获取数据
		var serverUrl = window.plus.platform.PluginFunctionSync("getApplicationMetaData", {
			key: "ServerUrl"
		});
		return serverUrl;
	};

	/**
	 * 根据键名，获取手机运用程序的元数据信息
	 * @param {Object} keyName
	 */
	owner.GetApplicationMetaData = function(keyName) {
		//从缓存中获取数据
		var serverUrl = window.plus.platform.PluginFunctionSync("getApplicationMetaData", {
			key: keyName
		});
		return serverUrl;
	};
	owner.GetSplashImage = function(keyName) {
		//从缓存中获取数据
		var serverUrl = window.plus.platform.PluginFunctionSync("getSplashImage");
		return serverUrl;
	};
	owner.GetDeviceInfo = function(key) {
		var info = platform.GetData("platform.deviceinfo");
		if(!info.PackageID) {
			info = window.plus.platform.PluginFunctionSync("GetDeviceInfo");
		}
		switch(key) {
			case "SerialNumber":
				return info.SerialNum;
			case "Package":
				return info.PackageID;
			case "Version":
				return info.Version;  
			default:
				return info;
		}
	};

	/**
	 * 获取设备的序列号
	 */
	owner.GetSerialNumber = function() {
		return this.GetDeviceInfo("SerialNumber");
	}

	owner.GetPackage = function() {
		return this.GetDeviceInfo("Package");
	}

	/**
	 *   说明 在手机目录下创建了 ASurverData的文件目录，如果传入的文件名相同，则自动追加内容
	 *   IOS 不支持
	 *   @param {Object} fileName  --文件名称，不用后缀 例如:  20160512  系统自动真名 20160512.txt
	 *   @param {Object} fileContent  fileContent 文件内容
	 */
	owner.WriteFileByAppend = function(fileName, fileContent) {
		//从缓存中获取数据
		var result = window.plus.platform.PluginFunctionSync("WriteFileByAppend", {
			fileName: fileName,
			fileContent: fileContent
		});
		return result;
	};
	/**
	 * 获取北京时间
	 * IOS 不支持
	 * 
	 */
	owner.GetBeiJingTime = function() {

		var result = window.plus.platform.PluginFunctionSync("GetBeiJingTime");
		return result;
	};

	owner.GetSQLiteData = function(key) {
		key = "$" + key;
		var data = window.plus.platform.PluginFunctionSync("GetData", key);
		return JSON.parse(data);
	};

	owner.SaveSQLiteData = function(key, value) {
		key = "$" + key;
		return window.plus.platform.PluginFunctionSync("SaveData", [{
			key: key,
			value: JSON.stringify(value)
		}]);
	};
	owner.RemoveSQLiteData = function(key) {
		key = "$" + key;
		return window.plus.platform.PluginFunctionSync("RemoveData", key);
	};
	owner.ClearSQLiteData = function() {
		return window.plus.platform.PluginFunctionSync("ClearData");
	};

	owner.GZip = function(data) {
		return window.plus.platform.PluginFunctionSync("GZip", [data]);
	};
	owner.GUnZip = function(data) {

		return window.plus.platform.PluginFunctionSync("GUnZip", [data]);
	};

})(window.platformCommon);